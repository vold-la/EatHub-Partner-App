package com.alam.eathub_staff;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UpdateInformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_information);
    }
}