package com.alam.eathub_staff.Common;

import com.alam.eathub_staff.Model.RestaurantOwner;

public class Common {
    public static final String API_RESTAURANT_ENDPOINT = "";
    public static final String API_KEY = "1234";

    public static RestaurantOwner currentRestaurantOwner;

}
